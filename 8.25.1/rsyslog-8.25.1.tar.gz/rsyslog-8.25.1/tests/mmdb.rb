version=2

rule=: %ip:word% %remaining:word%
