use Syslog;
truncate table SystemEvents;
